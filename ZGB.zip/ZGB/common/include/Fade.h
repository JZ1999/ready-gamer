#ifndef FADE_H
#define FADE_H

#include <gb/gb.h>

extern UINT8 fade_bank;
void FadeIn();
void FadeOut();

#endif