#include "Keys.h"

UBYTE previous_keys = 0;
UBYTE keys = 0;